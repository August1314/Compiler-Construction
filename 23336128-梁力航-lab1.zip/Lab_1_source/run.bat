@echo off
if not exist bin call build.bat
java -cp bin Postfix %*
pause
@echo on
